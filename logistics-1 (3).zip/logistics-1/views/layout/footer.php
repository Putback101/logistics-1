  <!-- Bootstrap bundle (for any existing Bootstrap components) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

  <!-- HR1 UI scripts (ported) -->
  <script src="<?= $base ?>/assets/js/hr_app.js"></script>
  <script src="<?= $base ?>/assets/js/hr_script.js"></script>

  <!-- Existing app script -->
  <script src="<?= $base ?>/assets/js/main.js"></script>
</body>
</html>
